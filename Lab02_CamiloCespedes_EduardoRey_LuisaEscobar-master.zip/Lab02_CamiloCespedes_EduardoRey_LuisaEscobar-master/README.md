# CovidTracker 🦠
## Simulación de contagios de COVID por medio de grafos. 
Grupo de trabajo: <br />
👨🏻‍💻 Camilo Cespedes <br />
👩🏻‍💻 Luisa Escobar <br />
👨🏻‍💻 Eduardo Rey <br />

## 🛠 Estamos trabajando en ello 🛠
